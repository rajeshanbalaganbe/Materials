package pages;

import wrappers.ProjectWrappers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TestCase extends ProjectWrappers {
	long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
	String emailId = "sita_SeleniumRDP"+number+"@xoxo.com";

	@BeforeClass
	public void setValues() {
		
		authors = "Sita";
		category = "Smoke";
		browserName = "chrome";
		dataSheetName = "TC001";
		
	}

	@Test
	public void tc01_RegisterNewUser() {
		
		testCaseName = "tc01_RegisterNewUser";
		testDescription = "Register New User";
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		invokeApp(browserName);
		clickByLink("Sign in");
		enterById("email_create", emailId);
		clickByXpath("//button[@id = 'SubmitCreate']/span");
		enterById("customer_firstname", prop.getProperty("Register.FirstName.Id"));
		enterById("customer_lastname", prop.getProperty("Register.LastName.Id"));
		enterById("email",emailId);
		
		enterById("passwd","P@ssword");
		enterById("address1", prop.getProperty("Register.Address.Id"));
		enterById("city", "Chicago");
		selectVisibileTextById("id_state", "Illinois");
		enterById("postcode", prop.getProperty("Register.Zip.Id"));
		enterById("phone_mobile", "1800552211");
		enterById("alias", prop.getProperty("Register.Alias.Id"));
		clickById("submitAccount");
		
	}
	
	@Test
	public void tc02_PerformUserAction() {
		
		testCaseName = "tc02_PerformUserAction";
		testDescription = "Perform actions for  New User";
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		invokeApp(browserName);
		clickByLink("Sign in");
//		enterById("authentication",  prop.getProperty("Register.Email.Id"));
//		enterById("passwd",  prop.getProperty("Register.Password.Id"));
//		clickById("SubmitLogin");
		
		
		
	}
	


	/**
	 * Class End
	 */

}
