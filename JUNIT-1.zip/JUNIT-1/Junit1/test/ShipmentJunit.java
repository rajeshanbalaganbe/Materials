import static org.hamcrest.CoreMatchers.*;

import java.text.SimpleDateFormat;
import java.util.*;
import org.junit.*;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.hamcrest.core.IsEqual;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class ShipmentJunit {

	private ShipmentBO shipmentBO;

	@Before
	public void createObjectForEmailGenerator() {
		shipmentBO = new ShipmentBO();

	}

	@Test
	public void testEmailId() {
		assertThat(shipmentBO.generateEmailId("Maddy Anderson", new Date("10/10/1997")),is("maddyanderson1997@gmail.com"));
		assertThat(shipmentBO.generateEmailId("MARTIN Blake", new Date("10/10/1992")),is("martinblake1992@gmail.com"));
		assertThat(shipmentBO.generateEmailId("MaROOn FiVE", new Date("10/10/2011")),is("maroonfive2011@gmail.com"));
		assertThat(shipmentBO.generateEmailId("mark hellary", new Date("10/10/2000")),is("markhellary2000@gmail.com"));
		
		
		
		
	
	}

}

