
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PurchaseOrderBO {

	PurchaseOrderDAO purchaseOrderDAO = new PurchaseOrderDAO();
    public void createPurchaseOrder(List<Item> items, Integer[] quantity,String customerName,String mobileNumber,Date orderDate) throws InsufficientQuantityException {
        
        PurchaseOrder purchaseOrder = new PurchaseOrder();
        purchaseOrder.setCustomerName(customerName);
        purchaseOrder.setMobileNumber(mobileNumber);
        purchaseOrder.setOrderDate(orderDate);
        purchaseOrder.setCreatedDate(new Date());
        List<OrderLine> lineList = new ArrayList<OrderLine>();
        Double totalamount = new Double(0) ;
        for(int i=0;i<items.size();i++) {
            
            Item item = items.get(i);
            if(item.getAvailableQuantity() < quantity[i]) {
                throw new InsufficientQuantityException("Item "+item.getName()+" is unavailable");
            }
            
            OrderLine line = new OrderLine();
            line.setItem(item);
            line.setPrice(item.getPrice());
            line.setPurchaseOrder(purchaseOrder);
            line.setQuantity(quantity[i]);
            lineList.add(line);
            totalamount = totalamount + item.getPrice();
        }
        
        purchaseOrder.setOrderLine(lineList);
        purchaseOrder.setTotalAmount(totalamount);
        purchaseOrder.setNumberOfItems(items.size());
        purchaseOrderDAO.createPurchaseOrder(purchaseOrder);
        
    }
    
    public List<PurchaseOrder> getAllPurchaseOrder() {
        return purchaseOrderDAO.getAllPurchaseOrder();
    }
    
    public void removeItemFromPurchaseOrder(long itemId) {
    	int i;
    	try {
    	for(i = 0;i<purchaseOrderDAO.getAllPurchaseOrder().get(0).getOrderLine().size();i++) {
    		if(itemId == purchaseOrderDAO.getAllPurchaseOrder().get(0).getOrderLine().get(i).getItem().getId()) {
    			break;
    		}
    	}
    	purchaseOrderDAO.getAllPurchaseOrder().get(0).getOrderLine().remove(i);
    	}catch(Exception e) {
    		System.out.println(e.getMessage());
    	}
    }
}