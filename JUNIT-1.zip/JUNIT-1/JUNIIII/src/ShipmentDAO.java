import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ShipmentDAO {
	static List<Shipment> shipments;
	static List<ShipmentStatus> shipmentStatus;

	static {
		shipments = new ArrayList<Shipment>();
		shipments.add(new Shipment(1, "shipment1", "kansas", "Missouri", 234,
				new ShipmentStatus(12, "Pending", 123)));
		shipments.add(new Shipment(2, "shipment2", "Dhaka", "Kansas", 2356,
				new ShipmentStatus(13, "Delayed", 124)));
		shipmentStatus = new ArrayList<ShipmentStatus>();
		shipmentStatus.add(new ShipmentStatus(12, "Pending", 123));
		shipmentStatus.add(new ShipmentStatus(13, "Delayed", 124));
	}

	public List<Shipment> getAllShipment() {
		return shipments;
	}

	public Shipment getShipmentByID(int id) throws Exception {
		for (Shipment e : shipments) {
			if (e.getId() == id)
				return e;
		}
		throw new Exception("Shipment for the given id is not found");
	}

	public ShipmentStatus getShipmentStatusByID(int id) throws Exception {
		for (ShipmentStatus e : shipmentStatus) {
			if (e.getId() == id)
				return e;
		}
		throw new Exception("Shipment for the given id is not found");
	}

	public List<ShipmentStatus> getAllShipmentStatus() throws SQLException {
		return shipmentStatus;
	}
}
