import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

/**
 * 
 * @author amphisoft
 */
public class Main {
	public static void main(String ags[]) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		ShipmentDAO shipmentDAO = new ShipmentDAO();
		ShipmentBO shipmentBO = new ShipmentBO();
		System.out.println("Enter the shipment details to be added:");
		Shipment shipmentToAdd = new Shipment();
		System.out.println("Shipment id:");
		shipmentToAdd.setId(Integer.parseInt(br.readLine()));
		System.out.println("Shipment Name:");
		shipmentToAdd.setName(br.readLine());
		System.out.println("Arrival port:");
		shipmentToAdd.setArrivalPortName(br.readLine());
		System.out.println("Departure port:");
		shipmentToAdd.setDeparturePortName(br.readLine());
		System.out.println("Cost:");
		shipmentToAdd.setCost(Integer.parseInt(br.readLine()));
		System.out.println("Shipment Status name:");
		int shipmentStausId = Integer.parseInt(br.readLine());
		shipmentBO.addShipment(shipmentToAdd, shipmentStausId, shipmentDAO);
		System.out.println("List of the Shipment Details");
		System.out.println(String.format("%-5s %-20s %-20s %-20s %-10s %s",
				"Id", "Name", "Arrival PortName", "Departure PortName", "Cost",
				"Status"));

		List<Shipment> shipmentList = shipmentDAO.getAllShipment();
		for (Shipment s1 : shipmentList) {
			System.out.println(String.format("%-5s %-20s %-20s %-20s %-10s %s",
					s1.getId(), s1.getName(), s1.getArrivalPortName(), s1
							.getDeparturePortName(), s1.getCost(), s1
							.getShipmentStatus().getName()));
		}
		System.out.println("Select the shipment id to be updated");
		int shipmentId = Integer.parseInt(br.readLine());
		System.out.println("Select the id of new shipment status");
		List<ShipmentStatus> shipmentStatusList = shipmentDAO
				.getAllShipmentStatus();
		for (ShipmentStatus s1 : shipmentStatusList) {
			System.out.println(s1.getId() + "." + s1.getName());
		}
		int shipmentStatusId = Integer.parseInt(br.readLine());
		shipmentBO.updateShipment(shipmentId, shipmentStatusId, shipmentDAO);
		List<Shipment> shipmentList2 = shipmentDAO.getAllShipment();
		System.out.println("List of the updated Shipment Details");
		System.out.println(String.format("%-5s %-20s %-20s %-20s %-10s %s",
				"Id", "Name", "Arrival PortName", "Departure PortName", "Cost",
				"Status"));

		for (Shipment s1 : shipmentList2) {
			System.out.println(String.format("%-5s %-20s %-20s %-20s %-10s %s",
					s1.getId(), s1.getName(), s1.getArrivalPortName(), s1
							.getDeparturePortName(), s1.getCost(), s1
							.getShipmentStatus().getName()));
		}
	}
}
