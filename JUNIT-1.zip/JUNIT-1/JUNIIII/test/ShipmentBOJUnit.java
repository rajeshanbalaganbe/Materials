import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class ShipmentBOJUnit {

	static List<Shipment> shipments;
	static List<ShipmentStatus> shipmentStatus;
	ShipmentDAO sDOA = new ShipmentDAO();
	ShipmentBO sBo = new ShipmentBO();

	@Test
	public void testUpdateShipment() {
		// fill the code
		try {
			sBo.updateShipment(1, 13, sDOA);
			Assert.assertTrue(sDOA.getShipmentByID(1).getShipmentStatus()
					.getName().equals("Delayed"));
		} catch (Exception e) {
			fail();
		}

	}

	@Test
	public void testUpdateShipment_failure() {
		// fill the code
		try {
			sBo.updateShipment(5, 13, sDOA);
			fail();
		} catch (Exception e) {
			Assert.assertEquals(
					"Update failed. Please enter a valid shipment id and shipment status id",
					e.getMessage());
		}
	}

	@Test
	public void testAddShipment() {
		// fill the code
		Shipment shipment = new Shipment(3, "shipment3", "Dhaka", "Kansas",
				1285, new ShipmentStatus(13, "Delayed", 124));
		try {
			sBo.addShipment(shipment, 13, sDOA);
			Assert.assertTrue(sDOA.getAllShipment().size() == 3);
		} catch (Exception e) {
			fail();
		}
	}

	@Test
	public void testAddShipment_failure() {
		// fill the code
		Shipment shipment = new Shipment(3, "shipment3", "Dhaka", "Kansas",
				1285, new ShipmentStatus(13, "Delayed", 124));
		try {
			sBo.addShipment(shipment, 15, sDOA);
			fail();
		} catch (Exception e) {
			Assert.assertEquals("Shipment for the given id is not found",
					e.getMessage());
		}
	}
}