package com.selenium.tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.selenium.pages.CustomerForm;
import com.selenium.setup.DriverSetup;

import setup.ExcelUtils;

public class TestCustomerForm extends DriverSetup {
	WebDriver driver;
	CustomerForm customerForm;
	static public String blankErrtxt;

	@BeforeClass
	public void setUp() {
		driver = getDriver();
		customerForm = new CustomerForm (driver);
	}
	@AfterClass
	public void closeBrowser(){
		driver.close();
	}
	
	
@DataProvider(name="customerInvalid")
public Object[][] getExcelData() throws Exception {
Object data[][] = ExcelUtils.readExcelData("customer_invalid");
return data;
}

@Test(dataProvider="customerInvalid")
public void testInvalidCustomerDetails(String customerName,String age, String address, String phoneNumber, String email ) throws Exception
{
	try {
		System.out.println("Entering the data");

		customerForm.setCustomerName(customerName);
		customerForm.setAge(age);
		customerForm.setAddress(address);
		customerForm.setPhoneNumber(phoneNumber);
		customerForm.setEmail(email);
		customerForm.submitForm();
		
	
		blankErrtxt = customerForm.getErrorMessage();
		
		if (blankErrtxt.contains("phoneNumber cannot be blank"))
		{
			System.out.println("Passed");
		}
		else
			System.out.println("Failed");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
