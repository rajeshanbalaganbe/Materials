package setup;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@SuppressWarnings("unused")
public class ExcelUtils {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static FileInputStream excelFile;
	private static String filePath;
	

public static Object[][] readExcelData(String sheetName) throws Exception{
	String[][] arrayExcelData= null;
		FileInputStream file = null;
		
		
	String workingDir = System.getProperty	("user.dir");
	filePath = workingDir+File.separator +"src"+File.separator+"customer_registration.xlsx";
              excelFile = new FileInputStream(filePath);
            ExcelWBook = new XSSFWorkbook(excelFile);
              ExcelWSheet = ExcelWBook.getSheet(sheetName);

	int rowcount=ExcelWSheet.getLastRowNum()-ExcelWSheet.getFirstRowNum();
	 arrayExcelData=new String[rowcount][5];
                 for(int i=0;i<rowcount;i++){
		 Row row=ExcelWSheet.getRow(i+1);
	                 for(int k=0;k<row.getLastCellNum();k++){
		Cell celval=row.getCell(k+1);
		if(celval!=null){
			arrayExcelData[i][k] =celval.getStringCellValue();
					  }
									 
				 }
			 }
			 return arrayExcelData;
					
	}
}

