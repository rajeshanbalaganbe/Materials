package com.selenium.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.selenium.setup.DriverSetup;

public class DisplayCustomer extends DriverSetup {
	
               By Title = By.xpath("/html/body/h2");
	By CustomerName=By.xpath("//tr[1]/td[2]");
	By CustomerAge=By.xpath("//tr[2]/td[2]");
	By CustomerEmail=By.xpath("//tr[5]/td[2]");
	By CustomerAddress=By.xpath("//tr[3]/td[2]");
	By CustomerPhoneNumber=By.xpath("//tr[4]/td[2]");
	
	WebDriver driver;
	public DisplayCustomer (WebDriver driver1)
	{
		this.driver=driver1;
	}
	

public String getTitle()
{
		String Titletxt = driver.findElement(Title).getText();
		return Titletxt;
}
	public String getName()
	{
		String nametxt = driver.findElement(CustomerName).getText();
		return nametxt;
	}
	public String getAge()
	{
		String unametxt = driver.findElement(CustomerAge).getText();
		return unametxt;
	}

	public String getEmail()
	{
		String emailtxt = driver.findElement(CustomerEmail).getText();
		return emailtxt;
	}
	public String getAddress()
	{
		String addresstxt = driver.findElement(CustomerAddress).getText();
		return addresstxt;
	}
	public String getPhoneNumber()
	{
		String phonenumbertxt = driver.findElement(CustomerPhoneNumber).getText();
		return phonenumbertxt;
	}
}
