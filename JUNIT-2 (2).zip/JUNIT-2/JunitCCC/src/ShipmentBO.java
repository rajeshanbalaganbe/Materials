import java.util.ArrayList;
import java.util.List;

public class ShipmentBO {

	ShipmentStatus findShipmentStatusByCode(String code,
			ShipmentStatus shipmentStatusList[]) {
		int i;
		ShipmentStatus shipmentStatus = null;
		for (i = 0; i < shipmentStatusList.length; i++) {
			if (shipmentStatusList[i].getCode().equals(code)) {
				shipmentStatus = shipmentStatusList[i];
			}
		}
		return shipmentStatus;
	}

	List<Shipment> getShipmentDetailsByStatus(String status,
			Shipment[] shipment) {
		Integer i;
		List<Shipment> shipments = new ArrayList<Shipment>();
		System.out.format("%-15s %-15s %-15s %-15s %-15s\n", "Name",
				"Arrivaldate", "Departuredate", "Statuscode", "Statusname");
		for (i = 0; i < shipment.length; i++) {
			if (shipment[i].getShipmentStatus().getName().contains(status)) {
				shipments.add(shipment[i]);
			}
		}
		return shipments;
	}
}
