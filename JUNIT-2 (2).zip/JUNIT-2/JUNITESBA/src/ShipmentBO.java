import java.util.ArrayList;

public class ShipmentBO {

	public ArrayList<String> getShipmentsOnSameDate(Integer n,
			Shipment[] shipments) {
		ArrayList<String> shipmentNames = new ArrayList<String>();
		// if (n > 0 && shipments.length == 0) {
		// throw new ArrayStoreException();
		// }
		for (int i = 0; i < n; i++) {
			// if (shipments[i].getArrivalDate() == null
			// || shipments[i].getDepartureDate() == null) {
			// throw new ArrayStoreException();
			// }
			if (shipments[i].getArrivalDate().compareTo(
					shipments[i].getDepartureDate()) == 0)
				shipmentNames.add(shipments[i].getName());
		}
		return shipmentNames;
	}

	public ArrayList<String> getShipmentsOnDiffDate(Integer n,
			Shipment[] shipments) {
		ArrayList<String> shipmentNames = new ArrayList<String>();
		// if (n > 0 && shipments.length == 0) {
		// throw new ArrayStoreException();
		// }
		for (int i = 0; i < n; i++) {
			// if (shipments[i].getArrivalDate() == null
			// || shipments[i].getDepartureDate() == null) {
			// throw new ArrayStoreException();
			// }
			if (shipments[i].getArrivalDate().compareTo(
					shipments[i].getDepartureDate()) != 0)
				shipmentNames.add(shipments[i].getName());
		}
		return shipmentNames;
	}
}
