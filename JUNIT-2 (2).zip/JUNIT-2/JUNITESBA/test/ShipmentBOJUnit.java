import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.fail;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
public class ShipmentBOJUnit {
	
	ShipmentBO shipmentBO;
    SimpleDateFormat dateFormat;
    ArrayList<String> shipmentNames;
    
    @Before
    public void initilaize()
    {
          shipmentBO = new ShipmentBO();
          dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    }
    
    @Test
    public void testGetShipmentsOnSameDate_withArrivalDateNull() {
          try {
                shipmentBO.getShipmentsOnSameDate(1, new Shipment[]{new Shipment("Hyd", dateFormat.parse("10-10-2017"), null)});
                fail("NullPointerException is not Thrown");
          }  catch (Exception e) {
                Assert.assertEquals("java.lang.NullPointerException", e.toString());
          }
          
    }

    @Test
	public void testGetShipmentsOnSameDate_withNoShipments() throws ParseException {
    	shipmentNames=shipmentBO.getShipmentsOnSameDate(1, new Shipment[]{new Shipment("Hyd", dateFormat.parse("10-10-2017"), dateFormat.parse("11-10-2017"))});
    	assertThat(shipmentNames.size(), is(0));
    	
	}
    @Test
	public void testGetShipmentsOnSameDate_withMultipleShipment() throws ParseException {
		shipmentNames=shipmentBO.getShipmentsOnSameDate(2, new Shipment[]{
				new Shipment("Chennai", dateFormat.parse("10-10-2017"), dateFormat.parse("10-10-2017")),
				new Shipment("Hyd", dateFormat.parse("11-11-2017"), dateFormat.parse("11-11-2017")),
				new Shipment("Mum", dateFormat.parse("10-10-2017"), dateFormat.parse("10-11-2017"))});
		 assertThat(shipmentNames, containsInAnyOrder("Chennai","Hyd"));
		 assertThat(shipmentNames, not(hasItems("Mum")));
	}
    @Test
	public void testGetShipmentsOnSameDate_withNoShipmentOnSameDate() throws ParseException {
		shipmentNames=shipmentBO.getShipmentsOnSameDate(1, new Shipment[]{new Shipment("Hyd", dateFormat.parse("10-10-2017"), dateFormat.parse("11-10-2017"))});
		assertThat(shipmentNames.isEmpty(), is(true));
		assertThat(shipmentNames.isEmpty(), is(not(false)));
	}
}
