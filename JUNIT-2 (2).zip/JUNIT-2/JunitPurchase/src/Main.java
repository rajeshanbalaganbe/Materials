
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class Main {

    public static void main(String args[]) throws IOException, ParseException {
        
        PurchaseOrderBO purchaseOrderBO = new PurchaseOrderBO();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        ItemDAO itemDAO = new ItemDAO();
        List<Item> itemList = itemDAO.getAllItems();
        Iterator<Item> itr = itemList.iterator();
        System.out.format("%-15s %-25s %-25s %-15s\n","Item ID","Name","Available Quantity","Price");
        while(itr.hasNext()) {
            Item item = itr.next();
            System.out.format("%-15s %-25s %-25s %-15s\n",item.getId(),item.getName(),item.getAvailableQuantity(),item.getPrice());
        }
        
        System.out.println("Creating new purchase order...");
        System.out.println("Enter Customer Name:");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String customerName = reader.readLine();
        System.out.println("Enter Contact Number:");
        String mobile = reader.readLine();
        System.out.println("Enter Order Date(dd/mm/yyyy):");
        Date orderDate = sdf.parse(reader.readLine());
        System.out.println("Enter all the Item ID you want to purchase:");
        String[] itemStr = reader.readLine().split(",");
        System.out.println("Enter number of quantities:");
        String[] quantitiesStr = reader.readLine().split(",");
        
        List<Item> purchaseItems = new ArrayList<Item>();
        Integer[] quantity = new Integer[itemStr.length];
        for(int i=0;i<itemStr.length;i++) {
            purchaseItems.add(itemDAO.getItemById(Long.parseLong(itemStr[i])));
            quantity[i] = new Integer(quantitiesStr[i]);
        }
        
        
        try {
            purchaseOrderBO.createPurchaseOrder(purchaseItems, quantity, customerName, mobile,orderDate);
            
            List<PurchaseOrder> purchaseOrders = purchaseOrderBO.getAllPurchaseOrder();
            
            for(int i=0;i<purchaseOrders.size();i++) {
                PurchaseOrder po = purchaseOrders.get(i);
                System.out.println("Order ID:1"+" "+"Customer Name:"+po.getCustomerName()+" "+"Mobile Number:"+po.getMobileNumber());
                System.out.println("Total Number of Items:"+po.getNumberOfItems()+" "+"Total Amount:"+po.getTotalAmount());
                
                List<OrderLine> olList = po.getOrderLine();
                System.out.format("%-30s%-30s%-30s\n","Item Name","Quantity","Price");
                for(int j=0;j<olList.size();j++) {
                    OrderLine ol = olList.get(j);
                    System.out.format("%-30s%-30s%-30s\n",ol.getItem().getName(),ol.getQuantity(),ol.getPrice());
                }
            }
        } catch (InsufficientQuantityException ex) {
            System.out.println(ex.getMessage());
        }
    }
    
}