import java.sql.SQLException;
import java.util.ArrayList;

public class UserBO {
	public ArrayList<User> fetchInactiveUsers(UserDAO userdao)
			throws SQLException, InstantiationException,
			IllegalAccessException, ClassNotFoundException {
		ArrayList<User> userList = userdao.getInActiveUsers();
		return userList;
	}

	public void inActivate(int failedAttempts, UserDAO userdao)
			throws InstantiationException, IllegalAccessException,
			ClassNotFoundException, SQLException {
		userdao.makeInActive(failedAttempts);
	}
}
