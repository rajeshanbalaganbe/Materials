import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class UserDAO {

	public void makeInActive(int failedAttempts) throws InstantiationException,
			IllegalAccessException, ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();

		String sql = "UPDATE user SET deleted = 1 where failed_attempts >="
				+ failedAttempts + "  ";
		stmt.executeUpdate(sql);

	}

	public ArrayList<User> getInActiveUsers() throws SQLException,
			InstantiationException, IllegalAccessException,
			ClassNotFoundException {
		ArrayList<User> userList = new ArrayList<User>();
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();
		String sql = "select * from user where deleted =1 order by username";
		ResultSet rs = stmt.executeQuery(sql);

		while (rs.next()) {
			User user = new User(rs.getInt("id"), rs.getString("username"),
					rs.getString("password"), rs.getString("address"),
					rs.getString("mobile_number"), rs.getInt("deleted"));
			userList.add(user);

		}
		return userList;
	}

}
