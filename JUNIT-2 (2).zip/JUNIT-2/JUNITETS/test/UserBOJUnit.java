public class UserBOJUnit {
	public void setUp() {
		//fill the code
	}

	public void testInActivate_withSQLException()
			throws InstantiationException, IllegalAccessException,
			ClassNotFoundException, SQLException {
		//fill the code
	}

	public void testInActivate() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException, SQLException {

		//fill the code
	}

	public void testFetchInActiveUsers() throws InstantiationException,
			IllegalAccessException, ClassNotFoundException, SQLException {

		//fill the code

	}

	private class MockUserDAO extends UserDAO {
		//fill the code
	}
}
