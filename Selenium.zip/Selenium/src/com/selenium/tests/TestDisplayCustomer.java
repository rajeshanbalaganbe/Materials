package com.selenium.tests;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import setup.ExcelUtils;

import com.selenium.pages.CustomerForm;
import com.selenium.pages.DisplayCustomer;
import com.selenium.setup.DriverSetup;





public class TestDisplayCustomer extends DriverSetup{
	
	WebDriver driver;
	DisplayCustomer displayCustomer;

              public static String titletxt;
public static String customerNametxt;
public static String agetxt;
public static String addresstxt;
public static String numbertxt;
public static String emailtxt;
	CustomerForm customerForm;


	@BeforeClass
	public void setUp() {
		driver = getDriver();
                             displayCustomer= new DisplayCustomer(driver);
                              customerForm = new CustomerForm(driver);
	}
	@AfterClass
	public void close(){
		driver.close();
	}
	@DataProvider(name ="customervalid")
	public Object[][] getExcelData() throws Exception {
		Object data [][]=ExcelUtils.readExcelData("customer_valid");
		return data;
	}

	@Test(dataProvider="customervalid")
	public void testValidCustomerDetails(String cName,String cAge, String cAddress, String cPhoneNumber, String cemail ) throws Exception{
		
		System.out.println("Entering the data");
		customerForm.setCustomerName(cName);
		customerForm.setAge(cAge);
		customerForm.setAddress(cAddress);
		customerForm.setPhoneNumber(cPhoneNumber);
		customerForm.setEmail(cemail);
		customerForm.submitForm();
		System.out.println(cName);
		
		displayCustomer = new DisplayCustomer (driver);
		String titletxt = displayCustomer.getTitle();
		System.out.println(titletxt);
		String customerNametxt =displayCustomer.getName();
		System.out.println(customerNametxt);
		String addresstxt = displayCustomer.getAddress();
		String agetxt = displayCustomer.getAge();
		String emailtxt = displayCustomer.getEmail();
		String numbertxt =displayCustomer.getPhoneNumber();
		
		try {
			Assert.assertEquals(titletxt, "Registered Succesfully");
			Assert.assertEquals(customerNametxt, cName+" "+cAge);
			Assert.assertEquals(agetxt, cAge);
			Assert.assertEquals(addresstxt, cAddress);
			Assert.assertEquals(numbertxt, cPhoneNumber);
			Assert.assertEquals(emailtxt, cemail);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	

}
}
