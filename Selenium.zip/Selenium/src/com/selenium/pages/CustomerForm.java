package com.selenium.pages ;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.selenium.setup.DriverSetup;



public class CustomerForm extends DriverSetup{

	By Name = By.name("cname");
	By Age = By.name("age");
	By Address = By.name("address");
	By PhoneNumber = By.name("phonenumber");
	By Email = By.name("email");
	By errorMessage = By.id("message");
	By submit = By.id("submit");
	
	WebDriver driver;
	
	public CustomerForm (WebDriver driver1)
	{
		this.driver = driver1;
	}

	public void setCustomerName(String cName)
	{
		driver.findElement(Name).sendKeys(cName);
	}

	public void setAge(String age)
	{
		driver.findElement(Age).sendKeys(age);
	}
	
public void setAddress(String address)
{
	driver.findElement(Address).sendKeys(address);
}

	public void setPhoneNumber(String phoneNumber)
	{
		driver.findElement(PhoneNumber).sendKeys(phoneNumber);
	}


	public void setEmail(String email)
	{
		driver.findElement(Email).sendKeys(email);
	}

	public String getErrorMessage()
	{
		String blankErrTxt = driver.findElement(errorMessage).getText();
		return blankErrTxt;
	}

	public void submitForm()throws Exception
	{
		driver.findElement(submit).click();
		Thread.sleep(5000);
	}
}
